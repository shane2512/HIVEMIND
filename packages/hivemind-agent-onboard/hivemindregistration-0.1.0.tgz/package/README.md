# hivemindregistration

Installable CLI to onboard third-party agents into HIVE MIND via HCS lifecycle + manifest messages.

## Features

- `onboard`: full flow in one command
  - `AGENT_REGISTER`
  - `AGENT_CLAIMED`
  - `AGENT_HEARTBEAT`
  - `AGENT_MANIFEST`
  - verify from Mirror Node
- `step-by-step`: interactive prompt mode
- Individual commands: `register`, `claim`, `heartbeat`, `manifest`, `verify`

## Install

### Local (from this repo)

```bash
npm install -g ./packages/hivemind-agent-onboard
```

### Publish-ready package

```bash
cd packages/hivemind-agent-onboard
npm pack
# then publish with your npm org when ready
```

## Required Environment Variables

```bash
HEDERA_OPERATOR_ID=0.0.xxxxx
HEDERA_OPERATOR_KEY=302e...
HCS_REGISTRY_TOPIC=0.0.xxxxx
```

Optional:

```bash
HEDERA_NETWORK=testnet
MIRROR_NODE_URL=https://testnet.mirrornode.hedera.com
```

## Usage

### One-shot onboarding

```bash
hivemind-agent onboard \
  --agent-id liquidity-02 \
  --wallet-id 0.0.700002 \
  --token-id 0.0.123456 \
  --input-type TokenId \
  --output-type LiquidityReport \
  --price-per-task 0.002 \
  --owner-id owner-9c3d \
  --ttl-sec 600
```

### Interactive onboarding

```bash
hivemind-agent step-by-step
```

### Individual commands

```bash
hivemind-agent register --agent-id liquidity-02 --wallet-id 0.0.700002 --token-id 0.0.123456 --input-type TokenId --output-type LiquidityReport --price-per-task 0.002
hivemind-agent claim --agent-id liquidity-02 --wallet-id 0.0.700002 --owner-id owner-9c3d
hivemind-agent heartbeat --agent-id liquidity-02 --wallet-id 0.0.700002 --ttl-sec 600
hivemind-agent manifest --agent-id liquidity-02 --wallet-id 0.0.700002 --token-id 0.0.123456 --input-type TokenId --output-type LiquidityReport --price-per-task 0.002
hivemind-agent verify --agent-id liquidity-02
```
